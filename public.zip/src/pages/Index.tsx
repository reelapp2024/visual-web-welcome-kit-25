
import React from 'react';
import ThemeIndex from '../components/ThemeIndex';

const Index = () => {
  return <ThemeIndex />;
};

export default Index;
