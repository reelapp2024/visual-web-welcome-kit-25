
import React from 'react';
import PlumbingFooter from '../themes/plumbing/components/PlumbingFooter';

const Footer = () => {
  return <PlumbingFooter />;
};

export default Footer;
