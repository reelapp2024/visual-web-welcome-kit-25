
import React from 'react';
import PlumbingHero from '../themes/plumbing/components/PlumbingHero';

const Hero = () => {
  return <PlumbingHero />;
};

export default Hero;
