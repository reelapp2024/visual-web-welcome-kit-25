
import React from 'react';
import PlumbingHeader from '../themes/plumbing/components/PlumbingHeader';

const Header = () => {
  return <PlumbingHeader />;
};

export default Header;
